$(".body-footer").load("footer.html");
$('document').ready(function() {
	
	//判断用户名和是是否合法
	$("#uname").blur(function() {
		var $uname = $('#uname').val();
		//判断用户名格式的正则表达式
		var reg = new RegExp(/^([A-Za-z0-9_\-\u4e00-\u9fa5]{6,20})$/, "g");
		var bool = reg.test($uname);
		var checkUname = $("#checkUname");
		if(bool == false) {
			checkUname.css("color", "red");
			checkUname.html("请输入6-20位合法用户名");
			
		} else {
			checkUname.html("&nbsp;");
		}
	});
	//判断密码格式是否合法
	$("#upwd").blur(function() {
		var $upwd = $('#upwd').val();
		var reg = new RegExp(/^(\w|@|\.|\-){6,20}$/, "g");
		var bool = reg.test($upwd);
		var checkUpwd = $("#checkUpwd");
		if(bool == false) {
			checkUpwd.css("color", "red");
			checkUpwd.html("请输入6-20位密码");
			
		} else {
			checkUpwd.html("&nbsp;");

		}
	});
	//异步的向服务器获取请求
	$("#submit").click(function() {
		//创建异步对象
		var xhr = createXhr();
		//设置监听对象
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				var result = xhr.responseText;
				console.log(result);
				if(result == "1")
				{
					alert("登录成功！");
					//登录成功后跳转到首页
					var str = "location.href='http://127.0.0.1:3000/index.html'";
					//eval将字符串解释称js代码执行
					eval(str);
				}else{
					alert("用户名或密码错误，请重新输入！")
				}
			}
		};
		//3.打开连接
		xhr.open('post', '/user/login', true);
		//将请求主题的格式更改成application/x-www-form-urlencoded
		xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		var $uname = $('#uname').val();
		var $upwd = $('#upwd').val();
		var formData = "uname=" + $uname + "&upwd=" + $upwd;
			//4.发送请求
		xhr.send(formData);
	});

});