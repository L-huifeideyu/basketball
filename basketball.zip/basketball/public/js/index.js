$('.body_top').load("top.html")
$(".body-nav-banner").load("nav-banner.html");
$(".body-footer").load("footer.html");
$('document').ready(function() {
	//异步向数据库读取首页主题部分数据
	(function() {
		var xhr = createXhr();
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				var result = xhr.responseText;
				var obj = JSON.parse(result);
				//主要新闻部分
				var html1 = `
						<div class="m_news_content row ">
							<div class="m_news_content_img col-lg-5 col-sm-12 col-12 text-center">
									<img src="${obj[0].img}" alt="" class="img-thumbnail" />
								</div>
								<div class="m_news_content_text col-lg-7 col-sm-12 col-12 text-center">
									<h4>
									<a href="${obj[0].href}">${obj[0].title}</a>
								</h4>
									<p>
										${obj[0].summary}
									</p>
							</div>
						</div>
						<div class="m_news_content row">
								<div class="m_news_content_img col-lg-5 col-sm-12 col-12 text-center">
									<img src="${obj[1].img}" alt="" class="img-thumbnail" />
								</div>
								<div class="m_news_content_text col-lg-7 col-sm-12 col-12 text-center">
									<h4>
									<a href="${obj[1].href}">${obj[1].title}</a>
								</h4>
									<p>
										${obj[1].summary}
									</p>
								</div>
							</div>
				`;
				$(".ajaxto1").html(html1);
				$(".ajaxto1 a").attr("target", "_blank");
				var html2 = `
							<div class="m_video_content col-lg-4 col-md-4 col-sm-12 col-12 text-center">
								<div class="m_video_content_title ">
									<h5><a href="${obj[2].href}">${obj[2].title}</a></h5>
									<div class="m_video_content_img">
										<img src="${obj[2].img}" class="img-thumbnail" />

									</div>
									<div class="m_video_content_detail">
										<p>${obj[2].summary}</p>

									</div>
								</div>
							</div>
							<div class="m_video_content col-lg-4 col-md-4 col-sm-12 col-12 text-center">
								<div class="m_video_content_title">
									<h5><a href="${obj[3].href}">${obj[3].title}</a></h5>
									<div class="m_video_content_img">
										<img src="${obj[3].img}" class="img-thumbnail" />

									</div>
									<div class="m_video_content_detail">
										<p>${obj[3].summary}</p>

									</div>
								</div>
							</div>
							<div class="m_video_content col-lg-4 col-md-4 col-sm-12 col-12 text-center">
								<div class="m_video_content_title">
									<h5><a href="${obj[4].href}">${obj[4].title}</a></h5>
									<div class="m_video_content_img">
										<img src="${obj[4].img}" class="img-thumbnail" />

									</div>
									<div class="m_video_content_detail">
										<p>${obj[4].summary}</p>

									</div>
								</div>
							</div>
				`;
				$(".ajaxto2").html(html2);
				$(".ajaxto2 a").attr("target", "_blank");
				var html3 = `
						<ul>
								<li>
									<a href="${obj[5].href}" class="text-left">${obj[5].title}</a>
								</li>
								<li>
									<a href="${obj[6].href}" class="text-left">${obj[6].title}</a>
								</li>
								<li>
									<a href="${obj[7].href}" class="text-left">${obj[7].title}</a>
								</li>
								<li>
									<a href="${obj[8].href}" class="text-left">${obj[8].title}</a>
								</li>
								<li>
									<a href="${obj[9].href}" class="text-left">${obj[9].title}</a>
								</li>
								<li>
									<a href="${obj[10].href}" class="text-left">${obj[10].title}</a>
								</li>
								<li>
									<a href="${obj[11].href}" class="text-left">${obj[11].title}</a>
								</li>

							</ul>
				`;
				$(".ajaxto3").html(html3);
				$(".ajaxto3 a").attr("target", "_blank");
				var html4 = `
							<div class="row mt-4 mb-2">
								<div class="m_hidden_father col-sm-12">
									<a href="${obj[12].href}" class="m_big_img"><img src="${obj[12].img}" class="w-100 img-thumbnail " /></a>
									<div class="m_hidden">
										<h5><a href="${obj[12].href}">${obj[12].title}</a></h5>
										<div class="m_hidden_content">

											<p>${obj[12].summary}</p>
										</div>
									</div>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-sm-5 col-5">
									<a href="${obj[13].href}"><img src="${obj[13].img}" class="img-thumbnail" /></a>
								</div>
								<div class="m_text col-sm-7 col-7">
									<p><a href="${obj[13].href}">${obj[13].title}</a></p>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-sm-5 col-5">
									<a href="${obj[14].href}"><img src="${obj[14].img}" class="img-thumbnail" /></a>
								</div>
								<div class="m_text col-sm-7 col-7">
									<p><a href="${obj[14].href}">${obj[14].title}</a></p>
								</div>
							</div>
				`;
				$(".ajaxto4").html(html4);
				$(".ajaxto4 a").attr("target", "_blank");
			}
		}
		xhr.open("get", "/index/", true);
		xhr.send(null);
	})();
});