$('.body_top').load("top.html");
$(".body-nav-banner").load("nav-banner.html");
$(".body-footer").load("footer.html");
$('document').ready(function() {

	$('#submit').click(function() {
		var $user_name = $("#user_name").val();
		var $user_mail = $("#user_mail").val();
		var $user_advice = $("#user_advice").val();
		var reg = new RegExp(/^(\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14})$/, "g");
		var bool = reg.test($user_mail);
		if(bool == false) {
			alert("请输入正确格式的Email");
		} else {
			var xhr = createXhr();
			xhr.onreadystatechange = function() {
				if(xhr.readyState == 4 && xhr.status == 200) {
					var result = xhr.responseText;
					if(result == 1) {
						alert("意见提交成功，请静候佳音");
					} else {
						alert("系统繁忙，请稍后再试");
					}
				}
			}
			xhr.open("post", "/mailus/", true);
			xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
			var formData = 'user_name=' + $user_name + '&user_mail=' + $user_mail + '&user_advice=' + $user_advice;
			xhr.send(formData);
		}

	})

})