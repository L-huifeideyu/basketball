$('document').ready(function(){
	(function (){
		var urlP = new URLSearchParams(location.search);
		var $nid = urlP.get('nid');
		var xhr = createXhr();
		xhr.onreadystatechange = function(){
			
			if(xhr.readyState == 4 && xhr.status == 200)
			{
				var result = xhr.responseText;
				var obj = JSON.parse(result);
				var html = `
					<div class="row pt-5">
					<div class="col-12 text-center">
						<h3 class="lead my_title">${obj.title}</h3>
					</div>
				</div>
				<div class="row mt-3">
					<div class="col-12 text-left">
						<h5 class="my_summary">摘要：${obj.summary}</h5>
					</div>
				</div>
				<div class="row mt-4">
					<div class="col-12 text-justify my_content">
						${obj.article}
					</div>
				</div>
				<div class="row mt-4 pb-5">
					<div class="col-12 text-left">
						<p class="my_from">(来自：${obj.n_from})</p>
					</div>
				</div>
				`;
				$('.ajaxto').html(html);
			}
		}
		xhr.open('get','/detail/select?nid=' + $nid,true);
		xhr.send(null);
	})();
	
	
	
	
	
});
