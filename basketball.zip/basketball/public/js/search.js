$(document).ready(function() {
	var urlSearch = new URLSearchParams(location.search);
	var search = urlSearch.get('search');
	//console.log(search);
	$("#search").val(search);

	function getInfo() {

		search = $("#search").val();
		//console.log(search);
		var xhr = createXhr();
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				var result = xhr.responseText;
				var obj = JSON.parse(result);
				var reg=new RegExp(search,"ig")
				var html = '';
				for(var i = 0; i < obj.length; i++) {
					obj[i].title = obj[i].title.replace(reg,"<span class='key'>"+search+'</span>');
					obj[i].summary = obj[i].summary.replace(reg,"<span class='key'>"+search+'</span>')
					html += `
						<div class="m_news_content row ">
							
								<div class="m_news_content_text col-12 text-left">
									<h4>
									<a href="${obj[i].href}${obj[i].nid}">${obj[i].title}</a>
									</h4>
									<p>${obj[i].summary}</p>
							</div>
						</div>
					`;
				}
				$('.search_res').html(html);
				$('span.key').css("color","red");
				$('.search_res a').attr("target", "_blank")
			}
		}
		xhr.open('get', '/banner/search?search=' + search, true);
		xhr.send(null);
	}
	getInfo();
	$("#btn").click(function() {
		getInfo();
	})
});