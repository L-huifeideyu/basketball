$('.body_top').load("top.html")
$(".body-nav-banner").load("nav-banner.html");
$(".body-footer").load("footer.html");
$('document').ready(function() {

	(function() {
		var xhr = createXhr();
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				var result = xhr.responseText;
				var obj = JSON.parse(result)

				var html = "";
				for(var i = 0; i < obj.length; i++) {
					html += `
						<div class="m_pic">
							<a href="${obj[i].href}${obj[i].nid}"><img src="${obj[i].img}" /></a>
							<p><a href="${obj[i].href}${obj[i].nid}">${obj[i].title}</a> </p>
						</div>
					`;
				}
				$('.ajaxtonews').html(html);
				$('.ajaxtonews a').attr("target", "_blank")
			}
		}
		xhr.open('get', '/cba/', true);
		xhr.send(null);
	})();

})