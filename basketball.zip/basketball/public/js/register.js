$(".body-footer").load("footer.html");
$('document').ready(function() {
	
	//记录用户名是否存在
	var isUname = false;
	var isUpwd = false;
	var isPhone = false;
	var isEmail = false;
	//判断用户名和是是否合法
	$("#uname").blur(function() {
		var $uname = $('#uname').val();
		var reg = new RegExp(/^([A-Za-z0-9_\-\u4e00-\u9fa5]{6,20})$/, "g");
		var bool = reg.test($uname);
		var checkUname = $("#checkUname");
		if(bool == false) {
			checkUname.css("color", "red");
			checkUname.html("请输入6-20位合法用户名");
		} else {
			//以下是判断用户名是否存在
			
			var xhr = createXhr();
			
			xhr.onreadystatechange = function(){
				
				if(xhr.readyState == 4 && xhr.status == 200)
				{
					
					var result = xhr.responseText;
					if(result == "1")
					{
						checkUname.css("color", "red");
						checkUname.html("用户名已存在");
					}else
					{
						checkUname.css("color","green");
						checkUname.html("用户名可用");
						isUname = true;
					}
				}
			};
			xhr.open('get','/user/selectUname?uname='+$uname,true);
			xhr.send(null);
					
		}	
	});
	//判断密码格式是否合法
	$("#upwd").blur(function() {
		var $upwd = $('#upwd').val();
		var reg = new RegExp(/^(\w|@|\.|\-){6,20}$/, "g");
		var bool = reg.test($upwd);
		var checkUpwd = $("#checkUpwd");
		if(bool == false) {
			checkUpwd.css("color", "red");
			checkUpwd.html("请输入6-20位密码");
		} else {
			checkUpwd.html("&nbsp;");
			isUpwd = true;
		}
	});
	//判断手机号是否合法
	$("#phone").blur(function(){
		var $phone = $("#phone").val();
		var reg = new RegExp(/^((\+86|0086)?\s*1[3-8]\d{9})$/,"g");
		var bool = reg.test($phone);
		var checkPhone = $("#checkPhone");
		if(bool == false)
		{
			checkPhone.css("color", "red");
			checkPhone.html("请输入合法手机号");	
		}else{
			checkPhone.css("color","green");
			checkPhone.html("手机号可用");
			isPhone = true;
		}
	});
		//判断邮箱格式是否合法
	$("#email").blur(function(){
		var $email = $("#email").val();
		var reg = new RegExp(/^(\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14})$/,"g");
		var bool = reg.test($email);
		var checkEmail = $("#checkEmail");
		if(bool == false)
		{
			checkEmail.css("color", "red");
			checkEmail.html("请输入正确格式的Email");	
		}else{
			checkEmail.css("color","green");
			checkEmail.html("Email可用");
			isEmail = true;
		}
	});
	
	$("#register").click(function(){
		if(isUname && isUpwd && isPhone && isEmail)
		{
			var xhr = createXhr();
			xhr.onreadystatechange = function(){
				if(xhr.readyState == 4 && xhr.status == 200)
				{
					var result = xhr.responseText;
					if(result == "1")
					{
						alert("注册成功，即将跳转到登录界面进行登录");
						var str = "location.href='http://127.0.0.1:3000/login.html'";
						eval(str);
					}else{
						alert("服务器繁忙，请稍后注册！！！")
					}
				}
			};
			//打开连接
			xhr.open("post",'/user/register',true);
			//修改请求头的文件传输格式
			xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			var $uname = $("#uname").val();
			var $upwd = $('#upwd').val();
			var $phone = $("#phone").val();
			var $email = $("#email").val();
			
			//拼接查询字符串
			var formData = 'uname='+$uname+'&upwd='+$upwd+'&phone='+$phone+'&email='+$email; 
			xhr.send(formData);
		}else{
			alert("您的注册信息有误，请返回检查！！！");
		}
	});
	
});