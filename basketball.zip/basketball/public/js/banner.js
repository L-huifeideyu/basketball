
$('document').ready(function() {

	//导航轮播图部分
	(function() {
		$("#search_btn").click(function() {
			//		window.open("search.html");
			var search = $("#search").val();
			//console.log(search);
			var url = "search.html?search=" + 　search;
			window.open(url);
		});
		//异步获取轮播图的图片数据
		var xhr = createXhr();
		xhr.onreadystatechange = function() {
			if(xhr.readyState == 4 && xhr.status == 200) {
				var result = xhr.responseText;

				var obj = JSON.parse(result);
				//轮播图
				var banner = `
					<div class="carousel-item active">
								<a href="${obj[0].href}" ><img src="${obj[0].img}" alt="" /></a>
								<div class="carousel-caption">
									<h3>${obj[0].title}</h3>
									
								</div>
							</div>
							<div class="carousel-item">
								<a href="${obj[1].href}"><img src="${obj[1].img}" alt="" /></a>
								<div class="carousel-caption">
									<h3>${obj[1].title}</h3>
									
								</div>
							</div>
							<div class="carousel-item">
								<a href="${obj[2].href}"><img src="${obj[2].img}" alt="" /></a>
								<div class="carousel-caption">
									<h3>${obj[2].title}</h3>
									
								</div>
							</div>
							<div class="carousel-item">
								<a href="${obj[3].href}"><img src="${obj[3].img}" alt="" /></a>
								<div class="carousel-caption">
									<h3>${obj[3].title}</h3>
									
								</div>
							</div>
				`;
				$('.ajaxToBanner').html(banner);
				$(".ajaxToBanner a").attr("target", "_blank");
			}
		}
		xhr.open('get', '/banner/', true);
		xhr.send(null);
	})();

})