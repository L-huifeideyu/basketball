
const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const user = require('./routes/user');
const index = require('./routes/index');
const detail = require('./routes/news_details');
const nba = require('./routes/NBA');
const cba = require('./routes/CBA');
const china = require('./routes/china')
const mailus = require('./routes/mail_us')
const banner = require('./routes/banner');
//构建web服务器
var app = express();
app.listen(3000,()=>{
	console.log('服务器创建成功');
});

//托管静态资源
app.use(express.static('./public'));
//配置session

//使用body-parser 中间件
app.use(bodyParser.urlencoded({
	extended : false
}));
//使用路由器
//把用户路由器挂载到 /user 下
app.use('/user',user);
//挂载主页路由
app.use('/index',index);
//挂载新闻详情路由
app.use("/detail",detail);
//挂载NBA页面路由
app.use('/nba',nba)
//挂载CBA页面路由
app.use('/cba',cba)
//挂载china页面路由
app.use('/china',china)
//挂载mail_us路由
app.use('/mailus',mailus)
//挂载轮播路由
app.use('/banner',banner);
