//连接数据库服务器
const mysql = require('mysql');
var pool = mysql.createPool({
	host:"127.0.0.1",
	port:3306,
	user:"root",
	password:"",
	database:"basketball",
	connectionLimit : 20
});
//导出数据库模块
module.exports = pool;