const express = require("express");
const pool = require("../pool.js");
var router = express.Router();

//用户登录
router.post('/login',(req,res)=>{
	var obj = req.body;
	var $uname = obj.uname;
	var $upwd = obj.upwd;
	var sql = "SELECT * FROM user WHERE uname = ? and upwd = ?";
	pool.query(sql,[$uname,$upwd],(err,result)=>{
		if(err) throw err;
		if (result.length > 0) {
			res.send("1");//登录成功
		} else{
			res.send("0");//登录失败
		};
	});
});
//查询用户名
router.get('/selectUname',(req,res)=>{
	var obj = req.query;
	var $uname = obj.uname;
	var sql = "SELECT uname FROM user WHERE uname = ?";
	pool.query(sql,$uname,(err,result)=>{
		if(err) throw err;
		
		if(result.length > 0)
		{
			res.send("1");//用户名已存在
		}else
		{
			res.send("0");//用户名可用
		}
	});
});
//用户注册
router.post('/register',(req,res)=>{
	var obj = req.body;
	var $uname = obj.uname;
	var $upwd = obj.upwd;
	var $phone = obj.phone;
	var $email = obj.email;
	var sql = 'INSERT INTO user(uname,upwd,phone,email) VALUES(?,?,?,?)';
	pool.query(sql,[$uname,$upwd,$phone,$email],(err,result)=>{
		if(err) throw err;
		if(result.affectedRows > 0)
		{
			res.send("1");//注册成功返回1；
		}else{
			res.send("0");//注册失败
		}
	});
});



//导出路由
module.exports = router;