const express = require('express');
const pool = require('../pool');
var router = express.Router();

router.get('/select',(req,res)=>{
	var $nid = req.query.nid;
	var sql = "SELECT * FROM news WHERE nid=?";
	pool.query(sql,[$nid],(err,result)=>{
		if(err) throw err;
		res.send(result[0]);

	});
});




//导出路由
module.exports = router;

