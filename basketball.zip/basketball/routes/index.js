const express = require('express');
const pool = require('../pool');
var router = express.Router();
//主页面新闻路由
router.get("/",(req,res)=>{
	var sql = "SELECT * FROM index_article";
	pool.query(sql,(err,result)=>{
		if(err) throw err;
		res.send(result);
		
	})
});
//主页面轮播图
router.get("/banner",(req,res)=>{
	var sql = "SELECT * FROM index_banner";
	pool.query(sql,(err,result)=>{
		if(err) throw err;
		res.send(result);
	})
})









//导出路由器
module.exports=router;
