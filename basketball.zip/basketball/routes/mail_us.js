const express = require('express');
const pool = require('../pool');
var router = express.Router();
//将收集到的意见信息存储到数据库
router.post("/",(req,res)=>{
	var obj = req.body;
	var $user_name = obj.user_name;
	var $user_mail = obj.user_mail;
	var $user_advice = obj.user_advice;
	var sql = "INSERT INTO mail_us(user_name,user_mail,user_advice) VALUES(?,?,?)";
	pool.query(sql,[$user_name,$user_mail,$user_advice],(err,result)=>{
		if(err) throw err;
		if(result.affectedRows > 0)
		{
			res.send("1");//意见存储成功
		}else{
			res.send("0");//意见存储失败
		}
	})
})








//导出路由器
module.exports=router;
