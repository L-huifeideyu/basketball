const express = require('express');
const pool = require('../pool');
var router = express.Router();
//主页面轮播图
router.get("/",(req,res)=>{
	var sql = "SELECT * FROM index_banner";
	pool.query(sql,(err,result)=>{
		if(err) throw err;
		res.send(result);
	})
})

router.get('/search',(req,res)=>{
	var $search = req.query.search;
	
	var regSearch = "%" +　$search + "%";

	var sql = "SELECT * FROM news WHERE title LIKE ?"
	pool.query(sql,regSearch,(err,result)=>{
		if(err) throw err;
		//console.log(result[1]);
		if(result.length > 0)
		{
			res.send(result);
			
		}else{
			res.send("查询失败!");
		}
	})
});








//导出路由器
module.exports=router;
